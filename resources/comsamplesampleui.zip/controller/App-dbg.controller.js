sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.sample.sampleui.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  